const errorHandler = require('./errorHandler');

module.exports = {
  errorHandler,
};
